#pragma once
#include "Node.h"
class QuanLy
{
public:
	Node* pHead;
	Node* pTail;
public:
	QuanLy();
	QuanLy(Node*);
	~QuanLy();
	bool isEmpty();
	int getLength();
	
	friend ostream& operator<<(ostream&, QuanLy&);
	Node *operator[](const int);
	void addFirst(const Node &);
	void addLast(const Node&);
	void addPosition(const Node&, int);
	void deleteFirst();
	void deleteLast();
	void deletePosition(int);
	void update();
	
	friend bool tD(string, string);
	friend bool gD(string, string);
	void swap(Node&, Node&);
	void sort();
	void sortMssv();
	Node* interpolationSearch(int, string);
};

