#include "SinhVien.h"

int main() {
	SinhVien sv;
	cout << sv;
	system("pause");
	return 0;
}