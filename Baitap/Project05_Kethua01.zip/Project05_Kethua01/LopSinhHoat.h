#pragma once
#include "Lecturer.h"

class SinhVien;
class LopSinhHoat
{
public:
	string lop;
	int n; //so luong sinh vien
	SinhVien* danhsachSV;
	Lecturer gvcn;
public:
	LopSinhHoat();
	~LopSinhHoat();
	string getLop();
	//friend class SinhVien;
};

